﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace OlympicGamesKennedy.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryID);
                });

            migrationBuilder.CreateTable(
                name: "Games",
                columns: table => new
                {
                    GameID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Games", x => x.GameID);
                });

            migrationBuilder.CreateTable(
                name: "OlympicTeams",
                columns: table => new
                {
                    OlympicTeamID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Country = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CategoryID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    GameID = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    FlagImage = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OlympicTeams", x => x.OlympicTeamID);
                    table.ForeignKey(
                        name: "FK_OlympicTeams_Categories_CategoryID",
                        column: x => x.CategoryID,
                        principalTable: "Categories",
                        principalColumn: "CategoryID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OlympicTeams_Games_GameID",
                        column: x => x.GameID,
                        principalTable: "Games",
                        principalColumn: "GameID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryID", "Name" },
                values: new object[,]
                {
                    { "AI", "Archery/Indoor" },
                    { "BI", "Breakdancing/Indoor" },
                    { "BO", "Bobsleigh/Outdoor" },
                    { "CI", "Curling/Indoor" },
                    { "CO", "Cycling/Outdoor" },
                    { "CSO", "Canoe Sprint/Outdoor" },
                    { "DI", "Diving/Indoor" },
                    { "RO", "Road Cycling/Outdoor" },
                    { "SO", "Skateboarding/Outdoor" }
                });

            migrationBuilder.InsertData(
                table: "Games",
                columns: new[] { "GameID", "Name" },
                values: new object[,]
                {
                    { "PA", "Paralympics" },
                    { "SU", "Summer Olympics" },
                    { "WO", "Winter Olympics" },
                    { "YO", "Youth Olympic Games" }
                });

            migrationBuilder.InsertData(
                table: "OlympicTeams",
                columns: new[] { "OlympicTeamID", "CategoryID", "Country", "FlagImage", "GameID" },
                values: new object[,]
                {
                    { "aut", "CSO", "Austria", "AUT.gif", "PA" },
                    { "bra", "RO", "Brazil", "BRA.gif", "SU" },
                    { "can", "CI", "Canada", "CAN.gif", "WO" },
                    { "chn", "DI", "China", "CHN.gif", "SU" },
                    { "cyp", "BI", "Cyprus", "CYP.gif", "YO" },
                    { "fin", "SO", "Finland", "FIN.gif", "YO" },
                    { "fra", "BI", "France", "FRA.gif", "YO" },
                    { "gbr", "CI", "Great Britain", "GBR.gif", "WO" },
                    { "ger", "DI", "Germany", "GER.gif", "SU" },
                    { "ita", "BO", "Italy", "ITA.gif", "WO" },
                    { "jam", "BO", "Jamaica", "JAM.gif", "WO" },
                    { "jpn", "BO", "Japan", "JPN.gif", "WO" },
                    { "mex", "DI", "Mexico", "MEX.gif", "SU" },
                    { "nld", "CO", "Netherlands", "NLD.gif", "SU" },
                    { "pak", "CSO", "Pakistan", "PAK.gif", "PA" },
                    { "prt", "SO", "Portugal", "PRT.gif", "YO" },
                    { "rus", "BI", "Russia", "RUS.gif", "YO" },
                    { "svk", "SO", "Slovakia", "SVK.gif", "YO" },
                    { "swe", "CI", "Sweden", "SWE.gif", "WO" },
                    { "tha", "AI", "Thailand", "THA.gif", "PA" },
                    { "ukr", "AI", "Ukraine", "UKR.gif", "PA" },
                    { "ury", "AI", "Uruguay", "URY.gif", "PA" },
                    { "usa", "RO", "USA", "USA.gif", "SU" },
                    { "zwe", "CSO", "Zimbabwe", "ZWE.gif", "PA" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_OlympicTeams_CategoryID",
                table: "OlympicTeams",
                column: "CategoryID");

            migrationBuilder.CreateIndex(
                name: "IX_OlympicTeams_GameID",
                table: "OlympicTeams",
                column: "GameID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "OlympicTeams");

            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "Games");
        }
    }
}
