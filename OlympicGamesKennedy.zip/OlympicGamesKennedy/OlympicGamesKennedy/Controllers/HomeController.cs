﻿using Microsoft.AspNetCore.Mvc;
using OlympicGamesKennedy.Models;

public class HomeController : Controller
{
    private OlympicTeamContext context;

    public HomeController(OlympicTeamContext ctx)
    {
        context = ctx;
    }

    public ViewResult Index(OlympicTeamViewModel model)
    {
        model.Games = context.Games.ToList();
        model.Categories = context.Categories.ToList();


        IQueryable<OlympicTeam> query = context.OlympicTeams.OrderBy(t => t.Country);
        if (model.ActiveGam != "all")
            query = query.Where(t =>
                t.Game.GameID.ToLower() ==
                     model.ActiveGam.ToLower());
        if (model.ActiveCateg != "all")
            query = query.Where(t =>
                t.Category.CategoryID.ToLower() ==
                     model.ActiveCateg.ToLower());
        model.OlympicTeams = query.ToList();
        return View(model);

    }
}

