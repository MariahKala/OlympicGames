﻿namespace OlympicGamesKennedy.Models
{
    public class Game
    {
        public string GameID { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;

        //The games are Youth Olympic Games, Paralympics, Summer Olympics, Winter Olympics
    }
}
