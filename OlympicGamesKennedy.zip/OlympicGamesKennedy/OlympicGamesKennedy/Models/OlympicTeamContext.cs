﻿using Microsoft.EntityFrameworkCore;

namespace OlympicGamesKennedy.Models
{
    public class OlympicTeamContext : DbContext
    {

        public OlympicTeamContext(DbContextOptions<OlympicTeamContext> options)
            : base(options) { }

        public DbSet<OlympicTeam> OlympicTeams { get; set; } = null!;
        public DbSet<Game> Games { get; set; } = null!;
        public DbSet<Category> Categories { get; set; } = null!;

        protected override void OnModelCreating(
        ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Game>().HasData(
                new Game { GameID = "SU", Name = "Summer Olympics" },
                new Game { GameID = "WO", Name = "Winter Olympics" },
                new Game { GameID = "PA", Name = "Paralympics" },
                new Game { GameID = "YO", Name = "Youth Olympic Games" }


        );

            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryID = "CI", Name = "Curling/Indoor" },
                new Category { CategoryID = "BO", Name = "Bobsleigh/Outdoor" },
                new Category { CategoryID = "DI", Name = "Diving/Indoor" },
                new Category { CategoryID = "RO", Name = "Road Cycling/Outdoor" },
                new Category { CategoryID = "CO", Name = "Cycling/Outdoor" },
                new Category { CategoryID = "AI", Name = "Archery/Indoor" },
                new Category { CategoryID = "CSO", Name = "Canoe Sprint/Outdoor" },
                new Category { CategoryID = "BI", Name = "Breakdancing/Indoor" },
                new Category { CategoryID = "SO", Name = "Skateboarding/Outdoor" }

        );
            modelBuilder.Entity<OlympicTeam>().HasData(
            new { OlympicTeamID = "can", Country = "Canada", GameID = "WO", CategoryID = "CI", FlagImage = "CAN.gif" },
            new { OlympicTeamID = "swe", Country = "Sweden", GameID = "WO", CategoryID = "CI", FlagImage = "SWE.gif" },
            new { OlympicTeamID = "gbr", Country = "Great Britain", GameID = "WO", CategoryID = "CI", FlagImage = "GBR.gif" },
            new { OlympicTeamID = "jam", Country = "Jamaica", GameID = "WO", CategoryID = "BO", FlagImage = "JAM.gif" },
            new { OlympicTeamID = "ita", Country = "Italy", GameID = "WO", CategoryID = "BO", FlagImage = "ITA.gif" },
            new { OlympicTeamID = "jpn", Country = "Japan", GameID = "WO", CategoryID = "BO", FlagImage = "JPN.gif" },
            new { OlympicTeamID = "ger", Country = "Germany", GameID = "SU", CategoryID = "DI", FlagImage = "GER.gif" },
            new { OlympicTeamID = "chn", Country = "China", GameID = "SU", CategoryID = "DI", FlagImage = "CHN.gif" },
            new { OlympicTeamID = "mex", Country = "Mexico", GameID = "SU", CategoryID = "DI", FlagImage = "MEX.gif" },
            new { OlympicTeamID = "bra", Country = "Brazil", GameID = "SU", CategoryID = "RO", FlagImage = "BRA.gif" },
            new { OlympicTeamID = "nld", Country = "Netherlands", GameID = "SU", CategoryID = "CO", FlagImage = "NLD.gif" },
            new { OlympicTeamID = "usa", Country = "USA", GameID = "SU", CategoryID = "RO", FlagImage = "USA.gif" },
            new { OlympicTeamID = "tha", Country = "Thailand", GameID = "PA", CategoryID = "AI", FlagImage = "THA.gif" },
            new { OlympicTeamID = "ury", Country = "Uruguay", GameID = "PA", CategoryID = "AI", FlagImage = "URY.gif" },
            new { OlympicTeamID = "ukr", Country = "Ukraine", GameID = "PA", CategoryID = "AI", FlagImage = "UKR.gif" },
            new { OlympicTeamID = "aut", Country = "Austria", GameID = "PA", CategoryID = "CSO", FlagImage = "AUT.gif" },
            new { OlympicTeamID = "pak", Country = "Pakistan", GameID = "PA", CategoryID = "CSO", FlagImage = "PAK.gif" },
            new { OlympicTeamID = "zwe", Country = "Zimbabwe", GameID = "PA", CategoryID = "CSO", FlagImage = "ZWE.gif" },
            new { OlympicTeamID = "fra", Country = "France", GameID = "YO", CategoryID = "BI", FlagImage = "FRA.gif" },
            new { OlympicTeamID = "cyp", Country = "Cyprus", GameID = "YO", CategoryID = "BI", FlagImage = "CYP.gif" },
            new { OlympicTeamID = "rus", Country = "Russia", GameID = "YO", CategoryID = "BI", FlagImage = "RUS.gif" },
            new { OlympicTeamID = "fin", Country = "Finland", GameID = "YO", CategoryID = "SO", FlagImage = "FIN.gif" },
            new { OlympicTeamID = "svk", Country = "Slovakia", GameID = "YO", CategoryID = "SO", FlagImage = "SVK.gif" },
            new { OlympicTeamID = "prt", Country = "Portugal", GameID = "YO", CategoryID = "SO", FlagImage = "PRT.gif" }




                 );

        }
    }
}
