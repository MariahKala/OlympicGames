﻿namespace OlympicGamesKennedy.Models
{
    public class Category
    {
        public string CategoryID { get; set; } = string.Empty; 
        public string Name { get; set; } = string.Empty;

        //The categories are Curling/Indoor - Bobsleigh/Outdoor - Diving/Indoor - Road Cycling/Outdoor - Cycling/Outdoor - Archery/Indoor - Canoe Sprint/Outdoor - Breakdancing/Indoor - Skateboarding/Outdoor
    }
}
